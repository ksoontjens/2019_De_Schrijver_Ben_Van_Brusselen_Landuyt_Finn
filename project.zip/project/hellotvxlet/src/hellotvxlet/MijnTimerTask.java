/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hellotvxlet;

import java.util.TimerTask;

/**
 *
 * @author bende
 */
public class MijnTimerTask extends TimerTask {

    boolean running=true;
    int speed=10;
    int counter=0;
    HelloTVXlet xlet;
    
    public void run() {
        counter++;
        if (counter>speed) { counter=0; }
        else return;
        if (running)
       xlet.tick();
    }

}
