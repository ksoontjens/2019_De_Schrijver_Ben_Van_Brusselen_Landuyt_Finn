package hellotvxlet;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.MediaTracker;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import javax.tv.xlet.*;

import org.bluray.ui.event.HRcEvent;
import org.dvb.event.EventManager;
import org.dvb.event.UserEvent;
import org.dvb.event.UserEventListener;
import org.dvb.event.UserEventRepository;
import org.havi.ui.HComponent;
import org.havi.ui.HIcon;
import org.havi.ui.HScene;
import org.havi.ui.HSceneFactory;
import org.havi.ui.HSound;
import org.havi.ui.HStaticText;
import org.havi.ui.HTextButton;
import org.havi.ui.HVisible;
import org.havi.ui.event.HActionListener;


public class HelloTVXlet extends HComponent implements Xlet, UserEventListener, HActionListener {

   MijnTimerTask mtt=new MijnTimerTask();
   Image img;
   Image img2;
   Image img3;
   Image img4;
   Image img5;
 
   Font f = new Font("Tiresias", Font.PLAIN, 42);
   Font f2 = new Font("Tiresias", Font.PLAIN, 34);
   
   boolean firstTime = true;
   int highscore = 0;
   int lastkip = 0;
   boolean iskip;
   boolean start = false;
   int randX;
   int randY;
   int maxLenght = 3;
   int x=100;
   int y = 100;
   int lengte=0;
   int richting=2; // 1= links 2=rechts 3= up 4=down
   int score = 0;
   int lastscore = 0;
   HStaticText txt = new HStaticText("Score: " + score, 400, -20, 500, 100);
   HStaticText deadtxt = new HStaticText("Your score was " + score + "!" + "  Highscore: " + highscore, 50, 100, 600, 200);
   ArrayList lijst=new ArrayList();
   ArrayList powerlijst=new ArrayList();
   ArrayList kiplijst=new ArrayList();
   HScene scene=HSceneFactory.getInstance().getDefaultHScene();
   public HelloTVXlet() {
        
    }

    public void initXlet(XletContext context) {
     
        HSound sound=new HSound();
        try {
            sound.load("audio.mp2");
        } catch (IOException ex) {
          ex.printStackTrace();
        } 
        sound.loop();
        
        HTextButton button=new HTextButton("Start Spel", 200, 250, 300, 100);
        scene.add(button);
        button.addHActionListener(this);
        button.setActionCommand("startspel");
        button.requestFocus();
        
        {
          randX = (int) (Math.random () * scene.getWidth() - 5);
          randY = (int) (Math.random () * scene.getHeight() - 5);
          
          img=  scene.getToolkit().getImage("image.png");
          img2=  scene.getToolkit().getImage("image2.png");
          img3=  scene.getToolkit().getImage("muis.gif"); //"power.png"
          img4=  scene.getToolkit().getImage("image3.png");
          img5=  scene.getToolkit().getImage("kip.gif");
          
          MediaTracker mt=new MediaTracker(this);
          mt.addImage(img, 1);
          mt.addImage(img2, 2);
          mt.addImage(img3, 3);
          mt.addImage(img4, 4);
          mt.addImage(img5, 5);
        try {

          mt.waitForAll();
        } catch (InterruptedException ex) {
          ex.printStackTrace();
        }

      scene.setBackgroundImage(img4);
      scene.setRenderMode(HScene.IMAGE_CENTER);
      scene.setBackgroundMode(HVisible.BACKGROUND_FILL);
      scene.setVisible(true);
         
      scene.validate();
      Timer t=new Timer();
      deadtxt.setFont(f);
      txt.setFont(f2);
      mtt.xlet=this;
  
      t.scheduleAtFixedRate(mtt, 0, 20);

      mtt.xlet=this;
      UserEventRepository rep=new UserEventRepository("naam");
      rep.addAllArrowKeys();
      (EventManager.getInstance()).addUserEventListener(this, rep);
      }
    }
  public boolean staatAlIets(Component c)
          {
      Component[] comps=scene.getComponents();
      for (int i=0;i<comps.length;i++)
      {
                  if (comps[i].getBounds().intersects(c.getBounds())) { 
                       return true;
                  }
      }
                  return false;
          }    
    public void tick()
    {
        if (start)
        {
       lengte++;
       if (richting==1) x-=37; 
       else if(richting==2) x+=37;
       else if(richting==3) y-=37;
       else if (richting==4) y+=37;
        
         HIcon icon2=new HIcon(img,x,y,img.getWidth(scene),img.getHeight(scene));
         icon2.setBordersEnabled(false);
      
          scene.add(icon2);
          scene.repaint();
          lijst.add(icon2);
          
          if( lijst.size()>maxLenght)
          {
              scene.remove((HIcon)lijst.get(0));
              lijst.remove(0); //lijst.get(0)
          }

          if (firstTime)
          {
              randX = (int) ( 25 + Math.random () * (scene.getWidth() - img3.getWidth((scene)) - 25));
              randY = (int) ( 25 + Math.random () * (scene.getHeight() - img3.getHeight((scene)) - 25));
              HIcon power = new HIcon(img3, randX, randY, img3.getWidth(scene), img3.getHeight(scene));
              power.setBordersEnabled(false);
              scene.add(power);
              powerlijst.add(power);
              firstTime = false;
          }
          
          if (score > (lastkip + 9) && !iskip)
          {
              randX = (int) (25 + Math.random () * (scene.getWidth() - img5.getWidth(scene) - 25));
              randY = (int) (25 + Math.random () * (scene.getHeight() - img5.getHeight(scene) -25));
              boolean isOk=false;
                    HIcon kip=null;
                    
              while (!isOk)
              {
              randX = (int) (25 + Math.random () * (scene.getWidth() - img5.getWidth(scene) - 25));
              randY = (int) (25 + Math.random () * (scene.getHeight() - img5.getHeight(scene) -25));
              kip = new HIcon(img5, randX, randY, img5.getWidth(scene), img5.getHeight(scene));
              isOk=true;
              if (staatAlIets(kip)) { isOk=false; System.out.println("hier staat al iets:"+scene.findComponentAt(randX,randY)); }
        //      if (staatAlIets(randX,randY+kip.getHeight())) { isOk=false; System.out.println("hier staat al iets:"+scene.findComponentAt(randX,randY)); }
          //    if (staatAlIets(randX+kip.getWidth(),randY+kip.getHeight())) { isOk=false; System.out.println("hier staat al iets:"+scene.findComponentAt(randX,randY)); }
            //  if (staatAlIets(randX+kip.getWidth(),randY)) { isOk=false; System.out.println("hier staat al iets:"+scene.findComponentAt(randX,randY)); }
              }
                    
              kip.setBordersEnabled(false);
              scene.add(kip);
              iskip = true;
              kiplijst.add(kip);
              lastkip = score;
          }
          
           if(iskip && testCollide((HIcon)lijst.get(lijst.size()-1),(HIcon)kiplijst.get(0)))
          {
              score += 3;
              scene.remove((HIcon)kiplijst.get(0));
              kiplijst.remove(0);
              maxLenght++;
               iskip = false;
          }
          
          if(testCollide((HIcon)lijst.get(lijst.size()-1),(HIcon)powerlijst.get(0)))
          {
              score++;
              scene.remove((HIcon)powerlijst.get(0));
              powerlijst.remove(0);
              maxLenght++;
              boolean isOk=false;
                    HIcon power=null;
              while (!isOk)
              {
                  
              
    
              randX = (int) (25 + Math.random () * (scene.getWidth() - img3.getWidth(scene))- 25);
              randY = (int) (25 + Math.random () * (scene.getHeight() - img3.getHeight(scene))- 25);
              power = new HIcon(img3, randX, randY, img3.getWidth(scene), img3.getHeight(scene));          isOk=true;
              if (staatAlIets(power)) { isOk=false; System.out.println("hier staat al iets:"+scene.findComponentAt(randX,randY)); }
     
          //    if (staatAlIets(randX,randY+power.getHeight())) { isOk=false; System.out.println("hier staat al iets:"+scene.findComponentAt(randX,randY)); }
      //        if (staatAlIets(randX+power.getWidth(),randY+power.getHeight())) { isOk=false; System.out.println("hier staat al iets:"+scene.findComponentAt(randX,randY)); }
        //      if (staatAlIets(randX+power.getWidth(),randY)) { isOk=false; System.out.println("hier staat al iets:"+scene.findComponentAt(randX,randY)); }
              }
              power.setBordersEnabled(false);
              scene.add(power);
              powerlijst.add(power);
          }
          
          if (score >= lastscore+10)
          {
            if (mtt.speed > 1)
            {
            mtt.speed -= 1;
            lastscore = score;
            }
          }
          
          txt.setTextContent("Score: " + score, HVisible.NORMAL_STATE);
          scene.add(txt);
          
          if (x > scene.getWidth() || x < 0 || y < 0 || y > scene.getHeight())
          {
              mtt.running = false;
              scene.removeAll();
              if (score > highscore) {highscore = score;}
              HTextButton button = new HTextButton ("Restart", 200, 300, 300, 100);
              deadtxt.setTextContent("Your score was " + score + "!" + "  Highscore: " + highscore, HVisible.NORMAL_STATE);
              scene.add(deadtxt);
              scene.add(button);
              button.setActionCommand("Restart");
              button.addHActionListener(this);
              
              button.requestFocus();
          }
          
          for (int i=0;i<(lijst.size())-1;i++)
          {
              if (testCollide((HIcon)lijst.get(lijst.size()-1),(HIcon)lijst.get(i)))
              {
              mtt.running = false;
              scene.removeAll();
              HTextButton button = new HTextButton ("Restart", 200, 300, 300, 100);
              if (score > highscore) {highscore = score;};
              deadtxt.setTextContent("Your score was " + score + "!" + "  Highscore: " + highscore, HVisible.NORMAL_STATE);
              scene.add(deadtxt);
              scene.add(button);
              button.setActionCommand("Restart");
              button.addHActionListener(this);
              button.requestFocus();
              }
          }
        }
          scene.repaint();
    }
    public boolean testCollide(HIcon i1, HIcon i2)
    {
        return i1.getBounds().intersects(i2.getBounds());
    }
    public void startXlet() {
    
    }

    public void pauseXlet() {
     
    }

    public void destroyXlet(boolean unconditional) {
     
    }

    public void userEventReceived(UserEvent arg0) {
       if (arg0.getCode()==HRcEvent.VK_LEFT)
       {
           if (richting != 2)
           {
           richting=1;
           }
       }
       if (arg0.getCode()==HRcEvent.VK_RIGHT)
       {
           if (richting != 1)
           {
           richting=2;
           }
       }
       if (arg0.getCode()==HRcEvent.VK_UP)
       {
           if (richting != 4)
           {
           richting=3;
           }
       }
       if (arg0.getCode()==HRcEvent.VK_DOWN)
       {
           if (richting != 3)
           {
           richting=4;
           }
       }
    }
    
    public void actionPerformed(ActionEvent args0)
    {
        if (args0.getActionCommand().equals("Restart"))
        {
            scene.removeAll();
            mtt.running = true;
            firstTime = true;
            powerlijst.clear();
            kiplijst.clear();
            iskip = false;
            lastkip = 0;
            score = 0;
            x = 100;
            y = 100;
            richting = 2;
            maxLenght = 3;
            mtt.speed = 10;
            lijst.clear();
        }
        
        if (args0.getActionCommand().equals("startspel"))
        {
            start =true;
            scene.removeAll();
            mtt.running = true;
            firstTime = true;
            score = 0;
            x = 100;
            y = 100;
            richting = 2;
            maxLenght = 3;
            mtt.speed = 10;
        }
    }
}
